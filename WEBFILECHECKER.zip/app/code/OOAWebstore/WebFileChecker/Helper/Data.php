<?php
namespace OOAWebstore\WebFileChecker\Helper;

/*
 *
* @category   OOA
* @package    OOA_WebFileChecker
* @copyright  Open Software (2016)
*
*/
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	protected $scopeConfig;
	
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
    	\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig    		
    ) {
    	$this->scopeConfig = $scopeConfig;
        parent::__construct(
            $context
        );
    }

	public function __()
	{
		$args = func_get_args();
		
		$locale = $this->scopeConfig->getValue('general/locale/code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

		if ($locale == 'nl_NL') {
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_EMAIL_SUBJECT1') {
	        	return 'WebFileChecker, geen aanpassingen gevonden!';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_EMAIL_SUBJECT2') {
	          	return 'WebFileChecker, aanpassingen gevonden, zie inhoud en bijlage!';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_EMAIL_SUBJECT3') {
	        	return 'WebFileChecker, alles is nieuw, email voor de eerste run te lang (zie log in admin)!';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_TITLE') {
	          	return 'Gecontroleerd op';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_ADDED_FILES') {
	          	return 'Toegevoegde bestanden';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_REMOVED_FILES') {
	          	return 'Verwijderde bestanden';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_CHANGED_FILES') {
	          	return 'Gewijzigde bestanden';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_ADDED_CONF') {
	        	return 'Toegevoegde configuratie instellingen';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_REMOVED_CONF') {
	        	return 'Verwijderde configuratie instellingen';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_CHANGED_CONF') {
	        	return 'Gewijzigde configuratie instellingen';
	        }
	        if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_VIEW') {
	        	return 'Toon';
	        }

		} else {
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_EMAIL_SUBJECT1') {
				return 'WebFileChecker, no modifications found!';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_EMAIL_SUBJECT2') {
				return 'WebFileChecker, modifications found, see context and attached list!';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_EMAIL_SUBJECT3') {
				return 'WebFileChecker, all new, email for the first run too long (see log in admin)!';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_TITLE') {
				return 'Checked at';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_ADDED_FILES') {
				return 'Added files';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_REMOVED_FILES') {
				return 'Removed files';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_CHANGED_FILES') {
				return 'Changed files';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_ADDED_CONF') {
				return 'Added configuration settings';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_REMOVED_CONF') {
				return 'Removed configuration settings';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_CHANGED_CONF') {
				return 'Changed configuration settings';
			}
			if ($args[0] == 'MODULE_OOA_WEBFILECHECKER_VIEW') {
				return 'View';
			}

		}

	}

}
