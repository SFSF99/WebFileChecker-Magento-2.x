<?php
namespace OOAWebstore\WebFileChecker\Controller\Adminhtml\Webfilechecker;

/*
 *
 * @category   OOA
 * @package    OOA_WebFileChecker
 * @copyright  Open Software (2016)
 *
 */
class Index extends \Magento\Backend\App\Action
{
	protected $wfcFactory;

	public function __construct(
		\Magento\Backend\App\Action\Context $context,
		\OOAWebstore\WebFileChecker\Model\WfcFactory $wfcFactory,
		array $data = []
	) {
		$this->wfcFactory = $wfcFactory;
		return parent::__construct($context, $data);				
	}
	
    public function execute()
    {
    	$wfc = $this->wfcFactory->create();
    	 
        $wfc->execute();
    }

}
