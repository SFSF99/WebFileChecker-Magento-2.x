<?php
namespace OOAWebstore\WebFileChecker\Controller\Adminhtml\Webfilechecker;

/*
 *
 * @category   OOA
 * @package    OOA_WebFileChecker
 * @copyright  Open Software (2016)
 *
 */
class View extends \Magento\Backend\App\Action
{

    public function execute()
    {

    	$this->_view->loadLayout();
    	$this->_addContent($this->_view->getLayout()->createBlock('OOAWebstore\WebFileChecker\Block\View'));
    	$this->_view->renderLayout();

    }

}
