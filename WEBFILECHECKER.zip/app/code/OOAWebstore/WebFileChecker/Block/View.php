<?php
namespace OOAWebstore\WebFileChecker\Block;

/*
 *
 * @category   OOA
 * @package    OOA_WebFileChecker
 * @copyright  Open Software (2016)
 *
 */
class View extends \Magento\Config\Block\System\Config\Form\Field
{
	
    protected function _toHtml()
    {
    	$file = dirname(dirname(dirname(dirname(dirname(dirname(__FILE__)))))) . "/var/wfc/ooa_wfc_mod.log";

    	if (file_exists($file)) {
	    	$str = file_get_contents($file);
    	} else {
    		$str = "...";
    	}	
    	
    	$html = str_replace("\r\n", "<br>", $str);

        return $html;
    }
    
}
