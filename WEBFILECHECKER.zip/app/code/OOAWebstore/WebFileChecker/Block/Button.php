<?php
namespace OOAWebstore\WebFileChecker\Block;

/*
 *
 * @category   OOA
 * @package    OOA_WebFileChecker
 * @copyright  Open Software (2016)
 *
 */
class Button extends \Magento\Config\Block\System\Config\Form\Field
{

    protected function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $this->setElement($element);

        $url = $this->getUrl('adminhtml/webfilechecker/view');

        $html = $this->getLayout()->createBlock('Magento\Backend\Block\Widget\Button')
                    ->setType('button')
                    ->setClass('scalable')
                    ->setLabel(__('MODULE_OOA_WEBFILECHECKER_VIEW'))
                    ->setOnClick("setLocation('$url')")
                    //->setOnClick("window.open('$url')")
                    ->toHtml();

        return $html;
    }
}
